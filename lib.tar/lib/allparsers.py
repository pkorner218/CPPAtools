import sys
from lib import basictools
import os

def validate_argparse_findaberrant_inputs(args):
#	print(args)
	valid_pst = ["codon","aminoacid","sequence", "startATGpos", "STOPpos", "FILEpos","regex"]
	fileendings = (".fa",".fasta",".fas",".tsv",".vcf")

	insequence = False

###

	if args.translation_error != "frameshift":
		args.remove_truncation = False

	if os.path.isfile(args.input): # input is a valid file

		if args.translation_error != 'mutation':
			if not (args.input.endswith(fileendings)):
				print("Invalid input file :", args.input, " file detected that is not in fasta, tsv, or vcf format")
				sys.exit(1)
                

	else: # input is supposedly a sequence # its not a valid file

		for char in [".","/",",","*","~"]:
			if char in args.input:
				print("Invalid input file :", args.input, " given filename does not seem to exist")
				sys.exit(1)
			else:
				insequence = True # input sequence is valid

				if args.translation_error == "frameshift":
					if args.position_string_type == "aminoacid":
						print("Please Note that frameshifting can not be performed without a given mRNA sequence. Please provide mRNA sequence instead.")
						sys.exit(1)



	if os.path.isfile(args.outfilename):
		print("Invalid output filename :", args.outfilename, " given outfilename does already exist")
		sys.exit(1)

	outendings = (".fa",".fasta",".fas")
	if not (args.outfilename.endswith(outendings)):
		print("Invalid output file name:", args.outfilename, " filename given that is not in .fasta .fa or .fas format")
		sys.exit(1)

	if "position_string_type" in args and args.position_string_type in valid_pst:

		if args.position_string_type == "regex":
			if args.mRNA_codon_aminoacid == "codon":
				print("regular expression can only be used on mRNA or AminoAcid level")
				sys.exit(1)


		if args.position_string_type == "codon":
			if not args.position_string in basictools.codon_AA_dictionary().keys():
				print("Invalid codon :", args.position_string)
				sys.exit(1)

			if args.mRNA_codon_aminoacid != "codon":
				print("Please be aware that position_string_type [codon] choice requires RNA_codon_aminoacid to also be [codon].\n Alternatively it is suggested to use position_string [sequence] with the codon as three letter nucleotide and the mRNA_codon_aminoacid [mRNA] option.")
				sys.exit(1)

		if args.position_string_type == "aminoacid":
			if not args.position_string in basictools.codon_AA_dictionary().values():
				print("Invalid amino acid :", args.position_string)
				sys.exit(1)

		if args.position_string_type == "sequence":
			for letter in args.position_string:
				if not letter in  basictools.codon_AA_dictionary().values():
					print("Invalid nucleoptide or amino acid found :", letter )
					sys.exit(1)

		if args.position_string_type == "FILEpos":
			if args.Reference is not None:
				if os.path.isfile(args.Reference):
					if not (args.Reference.endswith(fileendings)): 
						print("The given reference file", args.ref ,"is not a valid fasta file")
						sys.exit()
				else:
					if args.Reference not in ["hg19","hg38"]:
						print("The given reference is not valid", args.ref, "options are hg19/hg38")
						sys.exit()
			else:
				print("A Reference file -ref is required if using a position based fileinput")
				sys.exit(1)

			if args.position_string != "FILE":
				print("You chose to provide a file with positions (in -psl option). This requires the -ps option to be FILE")
				sys.exit(1)



	else:
		if args.translation_error != 'mutation' and args.translation_error != "vcf_file":
			print("Invalid input for position_string_type")
			sys.exit(1)

############


	if "mRNA_codon_aminoacid" in args and  args.mRNA_codon_aminoacid not in ["mRNA","codon","aminoacid"]:

		print("Invalid sequence level :", args.mRNA_aminoacid)
		sys.exit(1)


###################

	if insequence: # input is a sequence. check if it has proper nucleotides or amino acid letters
		if args.mRNA_codon_aminoacid == "mRNA":
			for letter in args.input:
				if not letter in ["A","C","G","T"]:
					print("Invalid nucleotide in the input sequence :", letter )
					sys.exit(1)

		if args.mRNA_codon_aminoacid == "aminoacid":
			for letter in args.input:
				if not letter in basictools.codon_AA_dictionary().values():
					print("Invalid amino acid in the input sequence :", letter )
					sys.exit(1)

####################

	if args.translation_error == "repeat":
		if not args.aberrantsequence in args.position_string:
			print("The given sequence to be repeated does not correlate with the sequence given to identify the positions were an event should occur. Either change the sequence to be repeated to be a subpart of the position_string sequence or alternatively provide it as -insertion sequence instead.")
			sys.exit(1)

	if args.translation_error == "insertion":
		if args.mRNA_codon_aminoacid != "aminoacid":
			if len(args.aberrantsequence) % 3 != 0:
				print("IMPORTANT NOTE: your given insertion sequence will create a frameshifted protein.")


####################

	if args.trypsin:
		if (args.trimm != False) or (args.sequencelength != False):
			print("the output option Trypsin, trimm and sequencelength are mutually exclusive. Please choose one")
			sys.exit()

	if "trimm" in args and (args.trimm != False):
		if (args.trypsin) or (args.sequencelength != False):
			print("the output option Trypsin, trimm and sequencelength are mutually exclusive. Please choose one")
			sys.exit()

	if (args.sequencelength != False):
		if (args.trypsin) or (args.trimm != False):
			print("the output option Trypsin, trimm and sequencelength are mutually exclusive. Please choose one")
			sys.exit()


##

def parse_all_findaberrant(parser):

	subparsers = parser.add_subparsers(required = True, dest="translation_error")

	p = subparsers.add_parser('frameshift', help='mRNA or Amino Acid sequence should be frameshifted')
	parser_Frameshift(p)

	p = subparsers.add_parser('repeat', help='mRNA or Amino Acid sequence should contain repeats')
	parser_Repeat(p)

	p = subparsers.add_parser('skip_deletion', help='mRNA or Amino Acid sequence should contain a skip or a deletion')
	parser_skip_deletion(p)

	p = subparsers.add_parser('truncation', help='mRNA or Amino Acid sequence should be truncated')
	parser_truncation(p)

	p = subparsers.add_parser('alternative_start', help='mRNA or Amino Acid sequence should have an alternative start site')
	parser_alternative_start(p)

	p = subparsers.add_parser('insertion', help='mRNA or Amino Acid sequence should have an insertion')
	parser_insertion(p)

	p = subparsers.add_parser('reversion', help='mRNA or Amino Acid sequence should contain a reverted piece')
	parser_reversion(p)

	p = subparsers.add_parser('mutation', help='mRNA mutation should be translated')
	parser_mutation(p)

	p = subparsers.add_parser('vcf_file', help='vcf file with mutations should be translated')
	parser_vcf(p)

def parser_findaberrant_common(parser):
	parser.add_argument("-i","--input", type = str, help = "Name of input. Either a fasta file [file.fasta], tab separated pos file (ENSTID/GeneID\tpos or chr:1-2) [file.tsv], a mutation file [file.vcf] or a single input sequence (mRNA or amino acid level) [ACGTGGAGACGAT]", required = True)
	parser.add_argument("-pst","--position_string_type", type = str, help = "The type of position where aberrant translation starts. options are ([codon], [aminoacid], [sequence], [startATGpos] (from start codon), [STOPpos] (from stop codon), [FILEpos] (from given tsv file or vcf file), [regex] regular expression in quotation marks ''", required = True)
	parser.add_argument("-ff","--force_frame", help= "In case you gave a sequence as -pst argument, this will only consider occurrences were the sequence was found to be in the normal reading frame", action='store_true')
	parser.add_argument("-ca","--codon_aware", help = "If you chose the -spt aminoacid option but still want the output sequences to be aware and include the different codons", action='store_true') 
	parser.add_argument("-ps","--position_string",  type = str, help = "The actual position where aberrance starts? (e.g [TTA] for codon, aminoacid [L], sequence [CTGGTGATTGATGCG], a position [9], based on input file [FILE])", required = True)
	parser.add_argument("-mca","--mRNA_codon_aminoacid", type = str, help= "is the event to be on mRNA [mRNA], codon [codon] or amino acid [aminoacid] level. This determines also the distances and lengths of other options to be counted either in nucleotides, or codons/amino acids! If you provide any vcf or chr based input mRNA level is required.", required = True)
	parser.add_argument("-ref","--Reference", type = str, help="REquired if running with a positionbased file. REFERENCE on mRNA or peptide (based on -mca choice) level to map the positions and mutations against. Given as file [reference.fa] or format [hg19,hg38].", required = False)
	#
	parser.add_argument("-nb","--NRbefore", type=int, help = "Minimum distance before the aberrant translation site [0]", required=False, default =0 )
	parser.add_argument("-na","--NRafter", type=int, help = "Minimum distance between aberrant translation site and canonical stop codon [0]", required=False ,default = 0)
	#
	parser.add_argument("-sl","--sequencelength", type = int, help="Minimum length of the created aberrant peptide after the aberrant translation site [100]", required = False, default =False)
	parser.add_argument("-trm","--trimm",type=str, help= "If true all sequences are trimmed to length of NR before and NR after, this can be used for oligo creation. The trimming is centered around the site of aberrant translation. NOT around the later aberrant sequence. please take this into account. The returned trimmed sequence is given on the level of the position string type.", required = False, default = False)
	parser.add_argument("-trp","--trypsin", help = "If this flag is used output amino acid sequences will be trypsinized into peptides at K/R. Peptide length is 5-55 amino acid", action='store_true') 
	#
	parser.add_argument("-o","--outfilename",type=str, help = "name of the outfile", required = True)
	#
	parser.add_argument("-aao", "--aminoacid_outlevel", help= "Level of your output file sequence default is aminoacid. Option changes fasta output format to mRNA sequence. Please be aware that this level can not be used in further pipeline",action='store_false')
	#
	parser.add_argument("-chr", help = "If this flag is used the positions in the input tsv are recognized as chromosome based", action="store_true") 
	#
	#
	parser.add_argument("-ct","--controltype", help = "Extra control type to be included, default random positions are always included. options are [controlscramble], [controlreverse], [controlrandom], [controlcharged], [all]", required = False)
	parser.add_argument("-cn","--controlnumber", help = "Number of controls per type to be included", required = False)
#
	parser.add_argument("-meta","--metadata", help = "Flag to turn on metadata. Will write a metadata file of the aberrant fasta file", action="store_true")
#	parser.add_argument("-NMD","--NonsenseMediatedDecay", type = float, help = "Filters out all aberrant peptides that are above the provided likelihood for NMD [number 0-1]", required=False)


def parser_mutation(parser):
	parser.add_argument("-i","--input", type = str, help = "Name of input. Either a fasta file [file.fasta], tab separated pos file (ENSTID/GeneID\tpos or chr:1-2) [file.tsv], a mutation file [file.vcf] or a single input sequence (mRNA or amino acid level) [ACGTGGAGACGAT]", required = True)
	parser.add_argument("-ref","--Reference", type = str, help="Required if running with a positionbased file. REFERENCE on mRNA or peptide (based on -mca choice) level to map the positions and mutations against. Given as file [reference.fa] or format [hg19,hg38].", required = False)
	parser.add_argument("-o","--outfilename",type=str, help = "name of the outfile", required = True)
	parser.add_argument("-sl","--sequencelength", type = int, help="Minimum length of the created aberrant peptide after the aberrant translation site [100]", required = False, default =False)
	parser.add_argument("-trp","--trypsin", help = "If this flag is used output amino acid sequences will be trypsinized into peptides at K/R. Peptide length is 5-55 amino acid", action='store_true') 


def parser_vcf(parser):
	parser.add_argument("-i","--input", type = str, help = "Name of input file [.vcf]", required = True)
	parser.add_argument("-ref","--Reference", type = str, help="Required if running with a positionbased file. REFERENCE on mRNA or peptide (based on -mca choice) level to map the positions and mutations against. Given as file [reference.fa] or format [hg19,hg38].", required = False)
	parser.add_argument("-o","--outfilename",type=str, help = "name of the outfile", required = True)
	parser.add_argument("-sl","--sequencelength", type = int, help="Minimum length of the created aberrant peptide after the aberrant translation site [100]", required = False, default =False)
	parser.add_argument("-trp","--trypsin", help = "If this flag is used output amino acid sequences will be trypsinized into peptides at K/R. Peptide length is 5-55 amino acid", action='store_true') 
	parser.add_argument("-aao", "--aminoacid_outlevel", help= "Level of your output file sequence default is aminoacid. Option changes fasta output format to mRNA sequence. Please be aware that this level can not be used in further pipeline",action='store_false')


def parser_Frameshift(parser):
	parser.add_argument("-fsd","--frameshift_direction", type=str, help = "In which direction should the frameshift be considered? [p1],[m1],[both])", required = True, default =None)
	parser.add_argument("-rt","--remove_truncation",  help = "Flag whether frameshifts resulting in immediate stop codons should be kept (default) or be removed (if -rt).", action="store_true")

	parser_findaberrant_common(parser)

def parser_Repeat(parser):
	parser.add_argument("-as", "--aberrantsequence", type=str, help = "The sequence, codon or amino acid to be repeated [TTG]", required = True)
	parser.add_argument("-n", "--number", type=int, help = "How often should the given sequence be repeated? [20] optional also a range can be given [1-10[ this will create all repeat options within the range " , required = True, default = None)
	parser_findaberrant_common(parser)

def parser_skip_deletion(parser):
	parser.add_argument("-l", "--length", type=str, help = "Length of the deletion or skip [20], to skip only a specific codon or amino acid the length should be 1 in accordance with the -ca option ", required = True)
	parser.add_argument("-nil", "--notincludelast", help = "If this flag is used the sequence were the event happens will not be included before the skip and will be deleted", action='store_true')
	parser_findaberrant_common(parser)

def parser_truncation(parser):
	parser.add_argument("-nil", "--notincludelast", help = "If this flag is used the sequence were the event happens will not be included before the skip and will be deleted", action='store_true')
	parser_findaberrant_common(parser)


def parser_alternative_start(parser):
	parser.add_argument("-nil", "--notincludelast", help = "If this flag is used the sequence were the event happens will not be included before the skip and will be deleted", action='store_true')
	parser_findaberrant_common(parser)

def parser_insertion(parser):
	parser.add_argument("-as", "--aberrantsequence", type=str, help = "The sequence, codon or amino acid to be inserted [TTG]", required = True)
	parser.add_argument("-nil", "--notincludelast", help = "If this flag is used the sequence were the event happens will not be included before the skip and will be deleted", action='store_true')
	parser_findaberrant_common(parser)

def parser_reversion(parser):
	parser.add_argument("-l", "--length", type=str, help = "Length of the reversion [20]", required = True)
	parser.add_argument("-nil", "--notincludelast", help = "If this flag is used the sequence were the event happens will not be included before the skip and will be deleted", action='store_true')
	parser_findaberrant_common(parser)

def parser_get_validated(parser):
	parser.add_argument("-t","--transcriptREF", type=str, help="transcript reference file (fasta format)", required=True)
	parser.add_argument("-p","--proteinREF", type=str, help="protein reference file (fasta format)", required=True)
	parser.add_argument("-o","--outfilename", type=str, help="name of the outfile to create (ending .fa or .fasta)", required=True)
	parser.add_argument("-c", "--CanonicalFilter",help="Only use longest transript per gene", action='store_true')
	parser.add_argument("-aao", "--aminoacid_outlevel", help= "Level of your output file sequence default is mRNA. Option changes fasta output format to aminoacid/peptide sequence. Please be aware that this level can not be used for frameshifting. Other aberrant translation options are possible though.",action='store_true' )

def parser_get_chem(parser):
	parser.add_argument("-i", "--input", help = "inputfile (fasta format)", required = True)
	parser.add_argument("-o","--outfilename", type=str, help="name of the outfile to create (ending .fa or .fasta", required = True)
	parser.add_argument("-p","--properties", type=str, help="names of the properties to use (comma , separated without spaces inbetween e.g boman,charge)", required = False, default ="all")

def parser_separate_fasta(parser):
	parser.add_argument("-n", "--number_entries", type = int, help = "number of entries to split fasta file into. Number of lines / 2 (>header\sequence)", required = False, default = 60000)
	parser.add_argument("-i", "--inputfastafile",  type=str,help = "inputfile aberrant fasta", required = True)
    
    
def parser_get_controls(parser):
	parser.add_argument("-i", "--input", help = "inputfile (fasta format)", required = True)
	parser.add_argument("-o","--outfilename", type=str, help="name of the outfile to create (ending .fa or .fasta", required = True)
	parser.add_argument("-p","--properties", type=str, help="names of the control properties to use (comma , separated without spaces inbetween e.g reverse,shuffle,random,false-positive-charged)", required = False, default ="all")
	parser.add_argument("-cn","--control_number",type=str, help="how many control sequences do you want for your properties? (comma , separated without spaces inbetween e.g 200,300,1000)", required = False, default ="1000")
   

    

def parser_get_secstruc(parser):
	parser.add_argument("-i", "--input", help = "inputfile (fasta format)", required = True)
	parser.add_argument("-o","--outfilename", type=str, help="name of the outfile to create", required = True)
	parser.add_argument("-of","--outputformat", type=str, help="which format should the output be in? default = 'diff', alternatively include only 'original' values", required=False, default = "diff")


def parser_getstats(parser):
	parser.add_argument("-i", "--input", help="inputfile", required=True)
	parser.add_argument("-o", "--outfilename", type=str, help="name of the outfile to create (automatic ending will be attached)", required=True)
	parser.add_argument("-t", "--inputtype", choices = ["chemproperties","secondary_structure","secondary_structure_diff","pdb_tmalign", "domains"], help="indicate the datatype of your inputfile [chemproperties],[secondary_structure], [secondary_structure_diff], [pdb_tmalign]", required=True)


def parser_get_pdbscores(parser):
	parser.add_argument("-d", "--inputdir", help="inputdir", required=True)
	parser.add_argument("-o", "--outfilename", type=str, help="name of the outfile to create", required = True)


############

def parser_domain_pipeline(parser):
    parser.add_argument("-i", "--input", help="Raw InterProScan TSV file.", required = True)
    parser.add_argument("-f", "--fasta", help="FASTA file containing the WT and OOF protein headers.", required = True)
    parser.add_argument("-d", "--database", help="SQLite background model database.", required=True)
    parser.add_argument("-c", "--count-matrix", help="Output TSV for the raw WT-vs-OOF domain count matrix.", required=True)
	parser.add_argument("-o", "--output", help="Output TSV for the final background-annotated per-OOF feature statistics.", required = True)
    parser.add_argument("--extracted-output", default=None, help="Optional output TSV for the normalized extracted InterPro feature table.")

###################

def parser_consensus_weighting(parser):
	parser.add_argument("-i","--inputfile",required=True,help="inputfile")
	parser.add_argument("-o","--outfilename",required=True,help="output prefix")
	parser.add_argument("-w","--weights",required=True,help="InterProScan tool weights"	)
	parser.add_argument("--score_absent_background",action="store_true",help="Assign high ranking scores to changed features absent from the background model")
	parser.add_argument("--absent_effect_per_copy",	type=float,	default=10.0,help="Pseudo-effect size per gained/lost copy for features absent from the background")
	parser.add_argument("--absent_pvalue",type=float,default=1e-6,help="Pseudo adjusted p-value used for scoring background-absent changed features")
	parser.add_argument("--consensus_group_column",	default="FeatureName",	help="Column used to group related tool calls before calculating ConsensusScore"	)
	parser.add_argument("--feature_summary_level",default="feature_id",choices=["feature_id","consensus_group"],help="Summarize ranked output per original FeatureID or per consensus group")
	parser.add_argument("--use_alternative_tool_weight_score",action="store_true",help="Use an alternative scoring mode: WeightedRankScore = BaseRankScore * ToolWeight")
	args = parser.parse_args()

