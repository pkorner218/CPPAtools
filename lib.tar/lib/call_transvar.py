import subprocess
import sys
import re
import argparse
import os


def cdna_mt(inputfile, REF): ### working

	infile = open(inputfile, "r")
	lines= infile.readlines()
	mtdict = {}

	for line in lines:

		FSseq = ""

		if REF == "":
			refassembly = "/home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa"
		else:
			assembly = REF

		inputmt = line.strip()
		gene = inputmt.split(":")[0]

		outstr1 = "".join(["transvar canno --noheader -i ",inputmt, " --reference /home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa --ensembl --longestcoding --print-protein-pretty"])
		fsresult = subprocess.getoutput(outstr1)

		fsresultlist = fsresult.split("\t")
		if len(fsresultlist) > 1:
			if "ENST" and "(protein_coding)" in fsresultlist[1] and "__[frameshift" in fsresultlist[-1]:

				ENST = fsresultlist[1]
				ENST = ENST.split(" ")[0]
				fspos = fsresultlist[4]
				gfspos, cfspos, AAfspos = fspos.split("/")
				fsexon = fsresultlist[5]

                
				if "inside_[cds" in fsexon:
					fsexon  = "exon" + fsexon[-2]
					seqs  = fsresultlist[-1].split(";")[5]
                    
					base, rest = seqs.split("__")
					base = base.split("=")[1]
					orig = rest.split(">")[0].split("_")[1]
					FS = rest.split(">")[1][:-2]
					origseq = base + orig
					FSseq = base + FS
					codonpos  = str(len(base))

					FSheader = ">" + "|".join([ENST,gene, fsexon]) + "|" + "_".join(["frameshift","fsdir",inputmt.replace("_","."),codonpos,"mRNA"])
					WTheader = ">" + "|".join([ENST,gene, "CDS","WT"])

					mtdict[WTheader] = origseq
					mtdict[FSheader] = FSseq


	return mtdict

def vcf_mt(infilename, REF):

#	infile = open(infilename, "r")
#	lines= infile.readlines()
	mtdict = {}

#	for line in lines:

#		FSseq = ""

	if REF == "":
		refassembly = "/home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa"
	else:
		assembly = REF

#		print(line)
	outstr1 = "".join(["transvar ganno --vcf ",infilename, " --noheader --reference /home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa --ensembl --longestcoding --print-protein-pretty"])
	#print(outstr1)
	fsresult = subprocess.getoutput(outstr1)

	lines = fsresult.split("\n")

	for line in lines:
		if not line.startswith("#") and line != "" and not line.startswith("[") and not line.startswith("Processed"):
			if "ENST" in line:
				resultlist = line.split("\t")
				#print(line)
				#print("")
                
                
				if len(resultlist) > 1:
					#if "protein_coding" in resultlist[8] and "protein_seq=" in resultlist:
					if "protein_seq=" in resultlist[13]:
						#print("result", resultlist[13])
						ENST = resultlist[8].split(" ")[0]
						gene = resultlist[9]
						mt = resultlist[11].split("/")[1]
						#print(ENST, Gene, mt)
						mainresult = resultlist[13]
						#print(mainresult)
						fsexon = resultlist[12]
						if "inside_[cds" in fsexon:
							fsexon  = "exon" + fsexon[-2]
						seqs = mainresult.split(";")[-3]
                        
#					seqs  = fsresultlist[-1].split(";")[5]
						base, rest = seqs.split("__")
						base = base.split("=")[1]
						orig = rest.split(">")[0].split("_")[1]
						FS = rest.split(">")[1][:-2]
						origseq = base + orig
						FSseq = base + FS
						codonpos  = str(len(base))

						FSheader = ">" + "|".join([ENST,gene, fsexon]) + "|" + "_".join(["frameshift","fsdir",mt.replace("_","."),codonpos,"mRNA"])
						WTheader = ">" + "|".join([ENST,gene, "CDS","WT"])

						mtdict[WTheader] = origseq
						mtdict[FSheader] = FSseq

#						print(base) 

                        
						#print("")
	return mtdict
#						gene_c_str = Gene + ":" + mt
#						converteds.append(gene_c_str)
#	return converteds


#	fsresultlist = fsresult.split("\n")
	#print(fsresultlist)

	#	if len(fsresultlist) > 1:
	#		if "ENST" and "(protein_coding)" in fsresultlist[1] and "__[frameshift" in fsresultlist[-1]:

	#			ENST = fsresultlist[1]
	#			ENST = ENST.split(" ")[0]
	#			fspos = fsresultlist[4]
	#			gfspos, cfspos, AAfspos = fspos.split("/")
	#			fsexon = fsresultlist[5]

                
	#			if "inside_[cds" in fsexon:
	#				fsexon  = "exon" + fsexon[-2]
	#				seqs  = fsresultlist[-1].split(";")[5]
     #               
	#				base, rest = seqs.split("__")
	#				base = base.split("=")[1]
	#				orig = rest.split(">")[0].split("_")[1]
	#				FS = rest.split(">")[1][:-2]
	#				origseq = base + orig
	#				FSseq = base + FS
	#				codonpos  = str(len(base))
#
#					FSheader = ">" + "|".join([ENST,gene, fsexon]) + "|" + "_".join(["frameshift","fsdir",inputmt.replace("_","."),codonpos,"mRNA"])
#					WTheader = ">" + "|".join([ENST,gene, "CDS","WT"])
#
#					mtdict[WTheader] = origseq
#					mtdict[FSheader] = FSseq
#	return mtdict

def vcf2cdna(infilename):

	converteds = []
	outstr1 = "transvar ganno --vcf " + infilename + " --noheader  --reference /home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa --ensembl --longestcoding --print-protein-pretty"

	fsresult = subprocess.getoutput(outstr1)
	lines = fsresult.split("\n")

	for line in lines:
		if not line.startswith("#") and line != "" and not line.startswith("[") and not line.startswith("Processed"):
			if "ENST" in line:
				resultlist = line.split("\t")
				print(line)
				print(resultlist)
				print("")
				if len(resultlist) > 1:
					if "protein_coding" in resultlist[8]:
						ENST = resultlist[8].split(" ")[0]
						Gene = resultlist[9]
						mt = resultlist[11].split("/")[1]
						gene_c_str = Gene + ":" + mt
						converteds.append(gene_c_str)
	return converteds


def chr_to_ENSTpos( input, level ):

	if os.path.isfile(str(input)):
		infile = open(input, "r")
		lines = infile.readlines()
	else:
		lines = input

	outlist = {}

	for line in lines:
		line = line.strip()

		if "chr" in line or ":c." in line: # [reg expression]
			chrpos = line
			outstr1 = "transvar " + level + " -i "  + "'" + chrpos + "'" + " --reference /home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa --ensembl --noheader --refversion hg38"
			chrresult = subprocess.getoutput(outstr1)
			chrlines = chrresult.split("\n")

			for chrline in chrlines: # every found match
				if not chrline.startswith("#") and chrline != "" and not chrline.startswith("[") and not chrline.startswith("Processed"):
					if "ENST" in chrline:
						resultlist = chrline.split("\t")

						if len(resultlist) > 1:
							if "protein_coding" in resultlist[1]:
								ENST = resultlist[1].split(" (")[0]
								Gene = resultlist[2]
								poss = resultlist[4]

								if ">/" in poss:
									gpos = poss.split(">/")[0]
									nucposstr = poss.split(">/")[1]
									protpos = poss.split(">/")[2]
								else:
									gpos = poss.split("/")[0]
									nucposstr = poss.split("/c.")[1]

								nucpos = re.findall(r'\d+',nucposstr)
								codonpos = resultlist[6].split(";")[1].split("=")[1]
								codonpos = list(codonpos.split("-"))

								if ENST not in outlist.keys():
									outlist[ENST] = [int(nucpos[0]),int(nucpos[0]),gpos, Gene]
	#print(outlist)
	return outlist

def validate_chrpos(outlist, REFdict):

	valout = {}
	nonvalidids = []
	valref = {}

	REFIDS = {}
	REFgenes = {}

	for key in REFdict.keys():
		ID = key.split("|")[0][1:]
		REFIDS[ID] = key
		REFgenes[ID] = key.split("|")[1]

	for ENST in outlist.keys():
		if ENST in REFIDS.keys():
			header = REFIDS[ENST]
			#print("$h$", header)
			gheader = "|".join(header.split("|")[:-1]) + "|" + outlist[ENST][2]
			#print("$g$", gheader)
			gene = outlist[ENST][3]

			#protpos = outlist[ENST][4]
			### is amino acid pos the same in ref file ??

			if gene == REFgenes[ENST]: ## gene is the same ...

				valref[ENST] = {gheader:REFdict[REFIDS[ENST]]}
				valout[gheader] = [outlist[ENST][:2]]
			#else:
				#nonvalidids.append(ENST)
		else:
			nonvalidids.append(ENST)

	if len(nonvalidids) > 0:
		print("! Warning", str(len(nonvalidids)), " given IDs are mathced to chr position but are not in reference ")

	return valout, valref




def getexonpos(ID, pos):

	Genemt = ID + ":" + "c." + str(pos)

	outstr1 = "transvar canno -i " + Genemt + " --noheader --ensembl  --reference /home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa"

	fsresult = subprocess.getoutput(outstr1)

#	print(outstr1)

	fsresultlist = fsresult.split("\t")

	

#	print(fsresult)
#	print("^^^^", fsresultlist)

	if not 'no_valid_transcript_found' in fsresultlist and fsresultlist != ['']:

#		print("&&&", fsresultlist)

		exon = fsresultlist[5]
		exonpos = int(re.findall(r'\d+',exon)[0])

		outstr2 = "transvar canno -i " + ID + " --noheader --ensembl --reference /home/pkorner/DATA/AberrPipeline/REF/GRCh38.p14.genome.fa"
		fsresult2 = subprocess.getoutput(outstr2)

		fsresultlist2 = fsresult2.split("\t")

#		print(fsresultlist2)

		totallength = int(fsresultlist2[4].split("/")[1].split("_")[1])

		totalexon = int(re.findall(r'\d+',fsresultlist2[6].split(";")[1])[0])


		return exonpos, totalexon, totallength

	else:
		return None, None, None



def NMD_algo(ID, abpos, exonposlist):

	exonpos = int(exonposlist[0])
	totalexon = int(exonposlist[1])
	totallength = int(exonposlist[2])

	NMD = "NA"

	#########################

#	print(totalexon, exonpos, totalexon > exonpos)

	if totalexon > exonpos:

		if abpos < 150:
			NMD = 0.12
		else:

			if abpos + 407 < totallength:
				abpos407 = getexonpos(ID, abpos + 407)
		#		print(pos407, "pos400")

				if abpos407 == exonpos:
					NMD = 0.41
				else:
					abpos50 = getexonpos(ID, abpos + 50)

					if abpos50 == totalexon:
						NMD = 0.2
					else:
						NMD = 0.65
			else:

				if abpos + 50 < totallength:
					abpos50 = getexonpos(ID, abpos + 50)

					if abpos50 == totalexon:
						NMD = 0.2
					else:
						NMD = 0.65
				else:
					NMD = 0.2

	else:
		NMD = 0

	return NMD